import { css } from 'styled-components';

const utils = css``;

export default utils;
